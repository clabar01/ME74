#include <Arduino.h>
/*
  ESP-NOW Signal Strength (RSSI) Monitor for two ESP32-S3 boards
  ---------------------------------------------------------------
  Flash this SAME sketch onto BOTH boards. No MAC addresses needed:
  each board broadcasts a small packet several times a second, and
  whenever it hears the other board it records the RSSI (signal strength).

  Each packet also carries the RSSI the sender last measured, so every
  board shows BOTH directions:
     "I hear peer at"   -> measured locally
     "Peer hears me at" -> reported back by the other board

  RSSI is in dBm and is always negative:
     -30 to -50  very strong (boards close together)
     -50 to -70  good / fair
     -70 to -85  weak
     below -85   about to drop out

  Requirements:
    - VS Code + PlatformIO (see platformio.ini for platform/board settings)
    - Upload: PlatformIO Upload; view output with PlatformIO Serial Monitor
    - If nothing prints, check the USB build_flags note in platformio.ini
    - Serial Monitor at 115200 baud
*/

#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <math.h>

// ======================= Settings you can tweak =======================
#define WIFI_CHANNEL        1      // Both boards must use the same channel
#define SEND_INTERVAL_MS    100    // How often each board transmits
#define PRINT_INTERVAL_MS   500    // How often results are printed
#define LOST_TIMEOUT_MS     2000   // No packets for this long = "lost"

// Lower TX power makes the signal fall off faster, so you can see the
// effect across a single room. Options include:
// WIFI_POWER_19_5dBm (max), WIFI_POWER_11dBm, WIFI_POWER_5dBm, WIFI_POWER_2dBm
#define TX_POWER            WIFI_POWER_19_5dBm

// Rough distance estimate (log-distance path loss model).
// Calibrate: put the boards exactly 1 m apart and set RSSI_AT_1M to the avg
// reading. PATH_LOSS_N is ~2.0 in open air, 2.5-4.0 indoors with obstacles.
#define RSSI_AT_1M          -45.0
#define PATH_LOSS_N         2.5
// ======================================================================

const uint32_t MAGIC = 0xB10C5EED;   // Identifies our packets
const int8_t   NO_RSSI = 127;        // "Nothing heard yet" marker

typedef struct __attribute__((packed)) {
  uint32_t magic;
  uint32_t seq;          // Sequence number, used to measure packet loss
  int8_t   rssiHeard;    // RSSI the sender measured from us
} Packet;

uint8_t broadcastAddr[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

// ---- Shared between receive callback (WiFi task) and loop() ----
portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;
volatile int8_t   latestRssi    = NO_RSSI;
volatile int8_t   peerReported  = NO_RSSI;
volatile int32_t  rssiSum       = 0;     // For averaging within a print window
volatile uint32_t rssiCount     = 0;
volatile uint32_t lastSeq       = 0;
volatile bool     haveSeq       = false;
volatile uint32_t received      = 0;     // Totals for packet-loss calculation
volatile uint32_t missed        = 0;
volatile uint32_t lastRxMs      = 0;
uint8_t           peerMac[6]    = {0};

uint32_t txSeq = 0;
float    smoothedRssi = NAN;             // Exponential moving average

// ---------------------------------------------------------------------
// Receive callback (ESP32 Arduino core 3.x signature)
// Keep this short: it runs inside the WiFi task.
// ---------------------------------------------------------------------
void onDataRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  if (len != sizeof(Packet)) return;
  Packet p;
  memcpy(&p, data, sizeof(p));
  if (p.magic != MAGIC) return;               // Ignore other ESP-NOW traffic

  int8_t rssi = info->rx_ctrl->rssi;

  portENTER_CRITICAL(&mux);
  latestRssi   = rssi;
  peerReported = p.rssiHeard;
  rssiSum     += rssi;
  rssiCount++;

  if (haveSeq && p.seq > lastSeq) {
    missed += (p.seq - lastSeq - 1);          // Gaps in sequence = lost packets
  }
  // If p.seq <= lastSeq the peer probably rebooted; just resync.
  lastSeq  = p.seq;
  haveSeq  = true;
  received++;
  lastRxMs = millis();
  memcpy(peerMac, info->src_addr, 6);
  portEXIT_CRITICAL(&mux);
}

// ---------------------------------------------------------------------
const char *qualityLabel(float rssi) {
  if (rssi >= -50) return "Excellent";
  if (rssi >= -60) return "Good";
  if (rssi >= -70) return "Fair";
  if (rssi >= -80) return "Weak";
  return "Very weak";
}

float estimateDistance(float rssi) {
  return powf(10.0f, (RSSI_AT_1M - rssi) / (10.0f * PATH_LOSS_N));
}

String signalBar(float rssi) {
  // Map -100 dBm..-30 dBm onto 0..30 characters
  int n = (int)((constrain(rssi, -100.0f, -30.0f) + 100.0f) * 30.0f / 70.0f);
  String bar = "[";
  for (int i = 0; i < 30; i++) bar += (i < n) ? '#' : ' ';
  bar += "]";
  return bar;
}

// ---------------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  delay(1000);

  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  esp_wifi_set_channel(WIFI_CHANNEL, WIFI_SECOND_CHAN_NONE);
  WiFi.setTxPower(TX_POWER);

  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW init failed! Restarting...");
    delay(2000);
    ESP.restart();
  }
  esp_now_register_recv_cb(onDataRecv);

  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, broadcastAddr, 6);
  peer.channel = 0;              // 0 = use current channel
  peer.ifidx   = WIFI_IF_STA;
  peer.encrypt = false;
  if (esp_now_add_peer(&peer) != ESP_OK) {
    Serial.println("Failed to add broadcast peer");
  }

  Serial.println();
  Serial.println("=== ESP-NOW RSSI Monitor ===");
  Serial.print("My MAC: ");
  Serial.println(WiFi.macAddress());
  Serial.printf("Channel %d, waiting for the other board...\n\n", WIFI_CHANNEL);
}

// ---------------------------------------------------------------------
void loop() {
  static uint32_t lastSend = 0, lastPrint = 0;
  uint32_t now = millis();

  // ---- Transmit ----
  if (now - lastSend >= SEND_INTERVAL_MS) {
    lastSend = now;
    Packet p;
    p.magic = MAGIC;
    p.seq   = ++txSeq;
    portENTER_CRITICAL(&mux);
    bool fresh = (now - lastRxMs) < LOST_TIMEOUT_MS && latestRssi != NO_RSSI;
    p.rssiHeard = fresh ? latestRssi : NO_RSSI;
    portEXIT_CRITICAL(&mux);
    esp_now_send(broadcastAddr, (uint8_t *)&p, sizeof(p));
  }

  // ---- Report ----
  if (now - lastPrint >= PRINT_INTERVAL_MS) {
    lastPrint = now;

    // Snapshot shared data
    portENTER_CRITICAL(&mux);
    int32_t  sum    = rssiSum;   rssiSum = 0;
    uint32_t count  = rssiCount; rssiCount = 0;
    int8_t   peerR  = peerReported;
    uint32_t rx     = received;
    uint32_t lost   = missed;
    uint32_t lastRx = lastRxMs;
    uint8_t  mac[6]; memcpy(mac, peerMac, 6);
    portEXIT_CRITICAL(&mux);

    if (rx == 0 || (now - lastRx) > LOST_TIMEOUT_MS) {
      Serial.println("No signal from peer (out of range or not powered)");
      smoothedRssi = NAN;
      return;
    }

    if (count > 0) {
      float windowAvg = (float)sum / count;
      smoothedRssi = isnan(smoothedRssi) ? windowAvg
                                         : 0.7f * smoothedRssi + 0.3f * windowAvg;
    }

    float lossPct = 100.0f * lost / (float)(rx + lost);

    Serial.printf("Peer %02X:%02X:%02X:%02X:%02X:%02X | I hear peer: %6.1f dBm %s %-9s",
                  mac[0], mac[1], mac[2], mac[3], mac[4], mac[5],
                  smoothedRssi, signalBar(smoothedRssi).c_str(),
                  qualityLabel(smoothedRssi));

    if (peerR != NO_RSSI) Serial.printf(" | Peer hears me: %4d dBm", peerR);
    else                  Serial.print (" | Peer hears me:   ---  ");

    Serial.printf(" | Loss: %4.1f%% | ~%.1f m\n",
                  lossPct, estimateDistance(smoothedRssi));
  }
}
